#########################################################################################
# Description:  Cava Global Rule Loader
# Created       Thu Mar 31 23:16:01 2011
# svn id        $Id: Global.pm 15 2012-06-14 15:24:10Z Mark Dootson $
# Copyright:    Copyright (c) 2011 Mark Dootson
# Licence:      This program is free software; you can redistribute it 
#               and/or modify it under the same terms as Perl itself
#########################################################################################

package Cava::Global;

# this module is a simple
# place holder to cause
# the Cava::Global module rule
# to be run second during a scan
# after the Cava::Project Rule

our $VERSION = '0.01';

1;
